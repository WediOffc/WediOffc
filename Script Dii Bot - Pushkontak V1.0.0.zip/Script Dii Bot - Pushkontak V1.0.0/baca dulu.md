Penting ‼️

Hapus/Ganti Bagian/Teks Ini? Masuk Neraka Paling Bawah

Reupload? Tag YouTube Gw : @DiiOffc
Jangan Jual Murah Sc Ini Kocak Apalagi Bagi Free

Script Ini Murni Bikinan Sendiri, Saya Hanya Sekedar Kroco Penghuni Inti Bumi.

Jika Ingin Membeli Kebutuhan Hosting Bisa Langsung Chat Dii Offc Minat Hubungi :
Wa¹ : https://wa.me/6285348168927
Wa² : https://wa.me/6282249398155
Tele : https://t.me/DiiOffc

Jangan Lupa Juga Join
https://t.me/RoomDiiOffc
https://t.me/TestiDiiOffc
https://chat.whatsapp.com/CEhwtjGZq2l7fLBbBzFsOt

Jangan Lupa Subscribe
https://youtube.com/@DiiOffc

Jangan Lupa Juga Kunjungi Website Kami
https://lynk.id/DiiOffc

Jangan Dihapus Creator Nya Kak
Saya Capek Ngetik Kode

"Wahai orang-orang yang beriman, mengapakah kamu mengatakan sesuatu yang tidak kamu kerjakan?
Amat besar kebencian di sisi Allah bahwa kamu mengatakan apa-apa yang tidak kamu kerjakan."
(QS ash-Shaff: 2-3).

Thanks To :                                
- Allah Swt 
- Nabi Muhammad Saw         
- My Parents       
- Dii Offc        
- Penyedia Apikey
- Penyedia Module
- Creator Bot Lainnya
- Pengguna Bot Yang Selalu Support