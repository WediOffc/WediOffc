/*
• Script  & Base By Dii Offc
• Mau Recode/Reupload? Simpen Nama Gw : DiiOffc / Dii Offc
• Mau Upload Di YouTube? Tag Akun Gw : @DiiOffc
• Hapus Credit Masuk Neraka Paling Bawah
• Jangan Lupa Enc Kalau Mau Di Publik/Run Pakai Panel, Nanti Kena Curi Kang Panel😱
• Buat Lu Yang Jual Sc Ini Yang Jujur Jangan Sampai Nipu Apalagi Lari Dari Tanggung Jawab Dosa Tanggung Sendiri
• Jangan Di Jual Murah Apalagi Di Kasih Free!!!
• Buat Lu Semua Yang Jual Murah Sc Ini Apalagi Di Kasih Free Gw Gak Bakal Update Lagi!!!
• Jika Ingin Recode Silakan Tapi Ingat Creditnya
• Script Dii Bot - Pushkontak Akan Terus Di Update, Jika Menjual Murah Script Ini Apalagi Membagikan Nya Secara Gratis Tidak Bakal Di Update Lagi
    
• Di Recode Ulang Oleh Nama Mu
• Thanks To Dii Offc Base Ori Dii Offc

Jangan Dihapus Creator Nya Kak
Saya Capek Ngetik Kode

"Wahai orang-orang yang beriman, mengapakah kamu mengatakan sesuatu yang tidak kamu kerjakan?
Amat besar kebencian di sisi Allah bahwa kamu mengatakan apa-apa yang tidak kamu kerjakan."
(QS ash-Shaff: 2-3).
    
NOTES:
Script Dii Bot - Pushkontak V1.0.0 Update Big 
WhatsApp¹ : https://wa.me/6285348168927
WhatsApp² : https://wa.me/6282249398155
Telegram : https://t.me/DiiOffc
YouTube : https://youtube.com/@DiiOffc
Website : https://lynk.id/DiiOffc
Group : https://chat.whatsapp.com/CEhwtjGZq2l7fLBbBzFsOt
Room Tele : https://t.me/RoomDiiOffc
Testimoni : https://t.me/TestiDiiOffc
*/

const { BufferJSON, WA_DEFAULT_EPHEMERAL, generateWAMessageFromContent, proto, generateWAMessageContent, generateWAMessage, prepareWAMessageMedia, areJidsSameUser, getContentType } = require('@whiskeysockets/baileys')
const { exec, spawn, execSync } = require("child_process")
const fs = require('fs')
const util = require('util')
const chalk = require('chalk')
const crypto = require('crypto')
const axios = require('axios')
const { rimraf } = require("rimraf")
const { pipeline } = require('stream')
const { promisify } = require('util')
const streamPipeline = promisify(pipeline)
const yts = require('yt-search')
const ytdl = require('ytdl-core')
const path = require('path')
const os = require('os')
const moment = require('moment-timezone')
const speed = require('performance-now')
const { performance } = require('perf_hooks')
const { smsg, getTime, sleep, runtime, fetchJson, getBuffer, getRandom, toRupiah, getGroupAdmins, ucapan, generateProfilePicture, pickRandom } = require('./lib/myfunc')
const { telegraPh } = require('./lib/screaper.js')
const { version } = require('./package.json')
const { toAudio, toVideo, toPTT } = require('./lib/converter')
const settings = JSON.parse(fs.readFileSync('./config.json'))

module.exports = DiiOffc = async (DiiOffc, m, chatUpdate, store) => {
try {
var body = (m.mtype === 'conversation') ? m.message.conversation : (m.mtype == 'imageMessage') ? m.message.imageMessage.caption : (m.mtype == 'videoMessage') ? m.message.videoMessage.caption : (m.mtype == 'extendedTextMessage') ? m.message.extendedTextMessage.text : (m.mtype === 'messageContextInfo') ? (m.message.buttonsResponseMessage?.selectedButtonId || m.message.listResponseMessage?.singleSelectReply.selectedRowId || m.text) : ''
var budy = (typeof m.text == 'string' ? m.text : '')
var prefix = /^[°•π÷×¶∆£¢€¥®™+✓_=|~!?@#$%^&.©^]/gi.test(body) ? body.match(/^[°•π÷×¶∆£¢€¥®™+✓_=|~!?@#$%^&.©^]/gi)[0] : "." 
const makeid = crypto.randomBytes(3).toString('hex')
const isCmd = body.startsWith(prefix)
const command = isCmd ? body.slice(prefix.length).trim().split(' ').shift().toLowerCase() : ''
const args = body.trim().split(/ +/).slice(1)
const pushname = m.pushName || "No Name"
const fullargs = body.replace(command, '').slice(1).trim()
const botNumber = await DiiOffc.decodeJid(DiiOffc.user.id)
const isOwner = settings.owner.includes(m.sender)
const isGroup = m.chat.endsWith('@g.us')
const isBot = m.sender == botNumber
const sender = m.key.fromMe ? (DiiOffc.user.id.split(':')[0]+'@s.whatsapp.net' || DiiOffc.user.id) : (m.key.participant || m.key.remoteJid)
const text = q = args.join(" ").trim()
const cmd = prefix + command
const quoted = m.quoted ? m.quoted : m
const mime = (quoted.msg || quoted).mimetype || ''
const qmsg = (quoted.msg || quoted)
const isMedia = /image|video|sticker|audio/.test(mime)
const groupMetadata = m.isGroup ? await DiiOffc.groupMetadata(m.chat).catch(e => {}) : ''
const groupName = m.isGroup ? await groupMetadata.subject : ''
const participants = m.isGroup ? await groupMetadata.participants : ''
const groupAdmins = m.isGroup ? await getGroupAdmins(participants) : ''
const isBotAdmins = m.isGroup ? groupAdmins.includes(botNumber) : false
const isAdmins = m.isGroup ? groupAdmins.includes(m.sender) : false
const contacts = JSON.parse(fs.readFileSync("./data/contacts.json"))

//~~~~~~~~~~ ALL FUNCTION ~~~~~~~~~~~//
let example = (teks) => {
return `\n*Contoh Penggunaan :*\nketik *${cmd}* ${teks}\n`
}

const createSerial = (size) => {
return crypto.randomBytes(size).toString('hex').slice(0, size)
}

switch(command) {
case "menu": {
var teks = `
*Menu - Main*
◦ ${prefix}ai
◦ ${prefix}script
◦ ${prefix}sticker

*Menu - Pushkontak*
◦ ${prefix}pushkontak
◦ ${prefix}pushkontak2
◦ ${prefix}cekid
◦ ${prefix}jpm
◦ ${prefix}broadcast

*Menu - Owner*
◦ ${prefix}setnamabot
◦ ${prefix}setthumbnail
`
DiiOffc.sendMessage(m.chat, {document: fs.readFileSync('./package.json'), fileName: settings.namabot, mimetype: 'application/rtf', fileLength: 900000000000000, pageCount: 999, caption: teks, contextInfo: { 
mentionedJid: [m.sender], 
externalAdReply: { 
thumbnailUrl: settings.thumbnail, 
title: 'WhatsApp Bot', 
body: null, 
renderLargerThumbnail: true, 
sourceUrl: settings.linkgc, 
mediaType: 1}}}, {quoted: m})}
break
case "sticker": case "s": case "stiker": {
if (/video/.test(mime)) {
if ((qmsg).seconds > 15) return m.reply("Durasi vidio maksimal 15 detik!")
var vid = await DiiOffc.downloadAndSaveMediaMessage(qmsg)
var res = await telegraPh(vid)
await DiiOffc.sendVideoAsSticker(m.chat, res, m, {
packname: settings.packname
})
await fs.unlinkSync(vid)
} else if (/image/.test(mime)) {
var img = await DiiOffc.downloadAndSaveMediaMessage(qmsg)
var res = await telegraPh(img)
await DiiOffc.sendImageAsSticker(m.chat, res, m, {
packname: settings.packname
})
await fs.unlinkSync(img)
} else return m.reply(example("dengan mengirim foto/video"))
}
break
case "jpm": case "broadcast": {
if (!isOwner && !botNumber) return m.reply(settings.mess.owner)
if (!text) return m.reply(example("pesannya"))
var foto
var ada 
var awal = m.chat
const aray = []
if (/image/.test(mime)) {
await DiiOffc.downloadAndSaveMediaMessage(qmsg).then(async (f) => {
foto = await telegraPh(f)
ada = true
await fs.unlinkSync(f)
})}
var teks = text
var id = await DiiOffc.groupFetchAllParticipating()
await Object.keys(id).forEach((e) => {
aray.push(`${id[e].id}`)
})
m.reply(`Memproses mengirim pesan ke *${aray.length}* Grup`)
for (let target of aray) {
var men = await DiiOffc.groupMetadata(target)
let orang = men.participants.map((e) => e.id)
if (ada == true) {
try {
await DiiOffc.sendMessage(target, {image: {url: foto}, caption: teks, contextInfo: {
mentionedJid: orang}})
} catch {}
} else {
try {
await DiiOffc.sendMessage(target, {text: teks, contextInfo: {mentionedJid: orang}})
} catch {}
}
await sleep(1500)
}
DiiOffc.sendMessage(awal, {text: `Berhasil mengirim pesan ke *${aray.length}* Grup ✅`}, {quoted: m})
}
break
case "ai": case "openai": {
if (!text) return m.reply(example("pertanyaanmu"))
m.reply(settings.mess.wait)
await fetch(`https://aemt.me/openai?text=${text}`)
.then((res) => res.json())
.then((hasil) => {
if (!hasil.status) return m.reply(settings.mess.error)
m.reply(hasil.result)
})}
break
case "setnamabot": case "setnama": {
if (!isOwner && !isBot) return m.reply(settings.mess.owner)
if (!text) return m.reply(example("Teksnya"))
settings.namabot = text
await fs.writeFileSync('./config.json', JSON.stringify(settings, null, 2))
m.reply("Berhasil mengubah *Nama Bot* ✅")}
break
case "setfoto": case "setthumbnail": {
if (!isOwner && !isBot) return m.reply(settings.mess.owner)
if (!/image/.test(mime)) return m.reply(example("Dengan reply/mengirim foto"))
var data = await DiiOffc.downloadAndSaveMediaMessage(qmsg)
var image = await telegraPh(data)
settings.thumbnail = image
await fs.writeFileSync('./config.json', JSON.stringify(settings, null, 2))
m.reply("Berhasil mengubah *Thumbnail Bot* ✅")
await fs.unlinkSync(data)}
break
case "pushkontak": case "puskon": {
if (db.data.bot.status) return m.reply("Tunggu proses pushkontak yang sebelumnya selsai!, agar terhindar dari spam")
if (!isBot && !isOwner) return m.reply(settings.mess.owner)
if (!text) return m.reply(example("idgrup|pesannya"))
if (!text.split("|")) return m.reply(example("idgrup|pesannya|jedawaktu"))
var idnya = text.split("|")[0]
if (!idnya.includes('@g.us')) return m.reply("*ID Grup* tidak valid!")
var mmk
var img = false
if (/image/.test(mime)) {
var media = await DiiOffc.downloadAndSaveMediaMessage(qmsg)
memk = await telegraPh(media)
img = true
}
const groupMetadataa = await DiiOffc.groupMetadata(`${text.split("|")[0]}`)
const participants = await groupMetadataa.participants
const halls = await participants.filter(v => v.id.endsWith('.net')).map(v => v.id)
var pesannya = text.split("|")[1]
var saya = [botNumber, settings.owner]
if (contacts.length > 1) {
contacts.splice(0, contacts.length)
await fs.writeFileSync("./data/contacts.json", JSON.stringify(contacts))
}
m.reply(`Memproses mengirim pesan ke *${halls.length}* Member`)
db.data.bot.status = true
var from = m.sender
for (let mem of halls) {
if (!saya.includes(mem)) {
contacts.push(mem)
fs.writeFileSync('./data/contacts.json', JSON.stringify(contacts))
if (img == true) {
await DiiOffc.sendMessage(mem, { image: { url: memk }, caption: pesannya })
await sleep(3000)
} else {
await DiiOffc.sendMessage(mem, { text: pesannya })
await sleep(3000)
}
}}
await m.reply(`Berhasil mengirim pesan ke *${halls.length} Member*, File Contact akan segera dikirim`)
await sleep(3000)
try {
const uniqueContacts = [...new Set(contacts)];
const vcardContent = uniqueContacts.map((contact, index) => {
if (!saya.includes(`${contact}`)) {
const vcard = [
"BEGIN:VCARD",
"VERSION:3.0",
`FN:WA[${createSerial(1)}] ${contact.split("@")[0]}`,
`TEL;type=CELL;type=VOICE;waid=${contact.split("@")[0]}:+${contact.split("@")[0]}`,
"END:VCARD",
"", ].join("\n");
return vcard; }}).join("");
await fs.writeFileSync("./data/contacts.vcf", vcardContent, "utf8");
} catch (err) {
m.reply(util.format(err))
} finally {
await DiiOffc.sendMessage(from, { document: await fs.readFileSync("./data/contacts.vcf"), fileName: "contacts.vcf", caption: "File Contact Berhasil Di Buat ✅", mimetype: "text/vcard", }, { quoted: m })
await sleep(3000)
contacts.splice(0, contacts.length)
await fs.writeFileSync("./data/contacts.json", JSON.stringify(contacts))
db.data.bot = {}
}}
break
case "pushkontak2": case "puskon2": {
if (db.data.bot.status) return m.reply("Tunggu proses pushkontak yang sebelumnya selsai!, agar terhindar dari spam")
if (!isBot && !isOwner) return m.reply(settings.mess.owner)
if (!text) return m.reply(example("idgrup|pesannya|jedawaktu\n\nJeda Waktu 1000 = 1 Detik"))
if (!text.split("|")) return m.reply(example("idgrup|pesannya|jedawaktu"))
var idnya = text.split("|")[0]
if (!idnya.includes('@g.us')) return m.reply("*ID Grup* tidak valid!")
var jedanya = text.split("|")[2]
if (isNaN(jedanya)) return m.reply("Masukan jedawaktu pakai angka!")
var mmk
var img = false
if (/image/.test(mime)) {
var media = await DiiOffc.downloadAndSaveMediaMessage(qmsg)
memk = await telegraPh(media)
img = true
}
const groupMetadataa = await DiiOffc.groupMetadata(`${text.split("|")[0]}`)
const participants = await groupMetadataa.participants
const halls = await participants.filter(v => v.id.endsWith('.net')).map(v => v.id)
var pesannya = text.split("|")[1]
var saya = [botNumber, settings.owner]
if (contacts.length > 1) {
contacts.splice(0, contacts.length)
await fs.writeFileSync("./data/contacts.json", JSON.stringify(contacts))
}
m.reply(`Memproses mengirim pesan ke *${halls.length}* Member`)
db.data.bot.status = true
var from = m.sender
for (let mem of halls) {
if (!saya.includes(mem)) {
contacts.push(mem)
fs.writeFileSync('./data/contacts.json', JSON.stringify(contacts))
if (img == true) {
await DiiOffc.sendMessage(mem, { image: { url: memk }, caption: pesannya })
} else {
await DiiOffc.sendMessage(mem, { text: pesannya })
}
await sleep(jedanya)}}
await m.reply(`Berhasil mengirim pesan ke *${halls.length} Member*, File Contact akan segera dikirim`)
await sleep(3000)
try {
const uniqueContacts = [...new Set(contacts)];
const vcardContent = uniqueContacts.map((contact, index) => {
if (!saya.includes(`${contact}`)) {
const vcard = [
"BEGIN:VCARD",
"VERSION:3.0",
`FN:WA[${createSerial(1)}] ${contact.split("@")[0]}`,
`TEL;type=CELL;type=VOICE;waid=${contact.split("@")[0]}:+${contact.split("@")[0]}`,
"END:VCARD",
"", ].join("\n");
return vcard; }}).join("");
await fs.writeFileSync("./data/contacts.vcf", vcardContent, "utf8");
} catch (err) {
m.reply(util.format(err))
} finally {
await DiiOffc.sendMessage(from, { document: await fs.readFileSync("./data/contacts.vcf"), fileName: "contacts.vcf", caption: "File Contact Berhasil Di Buat ✅", mimetype: "text/vcard", }, { quoted: m })
await sleep(3000)
contacts.splice(0, contacts.length)
await fs.writeFileSync("./data/contacts.json", JSON.stringify(contacts))
db.data.bot = {}
}}
break
case "listgc": case "id": case "cekid": {
if (!isBot && !isOwner) return m.reply(settings.mess.owner)
let gcall = Object.values(await DiiOffc.groupFetchAllParticipating().catch(_=> null))
let listgc = `\n  *📪 List Semua Group Chats*\n`
for (let u of gcall) {
listgc += `\n  *◦ Nama :* ${u.subject}\n  ◦ *ID :* ${u.id}\n  ◦ *Total Member :* ${u.participants.length}\n`
}
DiiOffc.sendText(m.chat, listgc, m)}
break
case "sc": case "script": case "scbot": {
if (isOwner || isBot) {
m.reply(settings.mess.wait)
let a = getTime().split("T")[0]
let b = getTime().split("T")[1].split("+")[0]
var name = `${a}◦${b}`
const ls = (await execSync("ls"))
.toString()
.split("\n")
.filter(
(pe) =>
pe != "node_modules" &&
pe != "session" &&
pe != "package-lock.json" &&
pe != "yarn.lock" &&
pe != ""
)
const anu = await execSync(`zip -r ${name}.zip ${ls.join(" ")}`)
await DiiOffc.sendMessage(settings.owner, {document: await fs.readFileSync(`./${name}.zip`), fileName: `${name}.zip`, 
mimetype: "application/zip"}, {quoted: m})
await execSync(`rm -rf ${name}.zip`)
if (isGroup) return m.reply("*Script Bot* berhasil dikirim ke private chat")
} else {
var res
await fetchJson(`https://aemt.me/tinyurl?link=https://wa.me/${settings.owner.split("@")[0]}`).then((link) => res = link.result).catch((error) => res = `https://wa.me/${settings.owner.split("@")[0]}`)
DiiOffc.relayMessage(m.chat, {
requestPaymentMessage: {
currencyCodeIso4217: 'IDR',
amount1000: 25000000,
requestFrom: m.sender, noteMessage: {
extendedTextMessage: { text: `
_Jika berminat dengan script bot ini silahkan ketik .owner atau klik tautan di bawah_\n\n☎ ${res}`, contextInfo: { externalAdReply: {
showAdAttribution: true}}}}}}, {qouted: m})}}
break
default:
if (budy.startsWith("=>")) {
if (!isOwner) return m.reply(settings.mess.owner)
try {
const evaling = await eval(`;(async () => { ${text} })();`);
return DiiOffc.sendMessage(m.chat, {text: util.format(evaling)}, {quoted: m})
} catch (e) {
return DiiOffc.sendMessage(m.chat, {text: util.format(e)}, {quoted: m})
}}

if (budy.startsWith(">")) {
if (!isOwner) return m.reply(settings.mess.owner)
try {
let evaled = await eval(text)
if (typeof evaled !== 'string') evaled = util.inspect(evaled)
DiiOffc.sendMessage(m.chat, {text: util.format(evaled)}, {quoted: m})
} catch (e) {
DiiOffc.sendMessage(m.chat, {text: util.format(e)}, {quoted: m})
}}

if (budy.startsWith("$")) {
if (!isOwner) return m.reply(settings.mess.owner)
m.reply("*Executing . . . . .*")
exec(text, (err, stdout) => {
if (err) return DiiOffc.sendMessage(m.chat, {text: err.toString()}, {quoted: m})
if (stdout) return DiiOffc.sendMessage(m.chat, {text: util.format(stdout)}, {quoted: m})
})
}

}
} catch (err) {
console.log(err)
DiiOffc.sendText(settings.owner, `*📢 Notifikasi Fitur Error :*\n\n${util.format(err)}`, m)
}}


let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.redBright(`Update ${__filename}`))
delete require.cache[file]
require(file)
})