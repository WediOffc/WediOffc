/*
• Script  & Base By Dii Offc
• Mau Recode/Reupload? Simpen Nama Gw : DiiOffc / Dii Offc
• Mau Upload Di YouTube? Tag Akun Gw : @DiiOffc
• Hapus Credit Masuk Neraka Paling Bawah
• Jangan Lupa Enc Kalau Mau Di Publik/Run Pakai Panel, Nanti Kena Curi Kang Panel😱
• Buat Lu Yang Jual Sc Ini Yang Jujur Jangan Sampai Nipu Apalagi Lari Dari Tanggung Jawab Dosa Tanggung Sendiri
• Jangan Di Jual Murah Apalagi Di Kasih Free!!!
• Buat Lu Semua Yang Jual Murah Sc Ini Apalagi Di Kasih Free Gw Gak Bakal Update Lagi!!!
• Jika Ingin Recode Silakan Tapi Ingat Creditnya
• Script Dii Bot - Pushkontak Akan Terus Di Update, Jika Menjual Murah Script Ini Apalagi Membagikan Nya Secara Gratis Tidak Bakal Di Update Lagi
    
• Di Recode Ulang Oleh Nama Mu
• Thanks To Dii Offc Base Ori Dii Offc

Jangan Dihapus Creator Nya Kak
Saya Capek Ngetik Kode

"Wahai orang-orang yang beriman, mengapakah kamu mengatakan sesuatu yang tidak kamu kerjakan?
Amat besar kebencian di sisi Allah bahwa kamu mengatakan apa-apa yang tidak kamu kerjakan."
(QS ash-Shaff: 2-3).
    
NOTES:
Script Dii Bot - Pushkontak V1.0.0 Update Big 
WhatsApp¹ : https://wa.me/6285348168927
WhatsApp² : https://wa.me/6282249398155
Telegram : https://t.me/DiiOffc
YouTube : https://youtube.com/@DiiOffc
Website : https://lynk.id/DiiOffc
Group : https://chat.whatsapp.com/CEhwtjGZq2l7fLBbBzFsOt
Room Tele : https://t.me/RoomDiiOffc
Testimoni : https://t.me/TestiDiiOffc
*/

const { default: makeWASocket, useMultiFileAuthState, DisconnectReason, makeInMemoryStore, jidNormalizedUser, makeCacheableSignalKeyStore, generateForwardMessageContent, generateWAMessageFromContent, downloadContentFromMessage, jidDecode, proto, getAggregateVotesInPollMessage, PHONENUMBER_MCC } = require("@whiskeysockets/baileys")
const pino = require('pino')
const { Boom } = require('@hapi/boom')
const fs = require('fs')
const yargs = require('yargs/yargs')
const NodeCache = require('node-cache')
const crypto = require('crypto')
const { say } = require('cfonts')
const chalk = require('chalk')
const FileType = require('file-type')
const readline = require('readline')
const path = require('path')
const _ = require('lodash')
const axios = require('axios')
const makeid = crypto.randomBytes(5).toString('hex')
const PhoneNumber = require('awesome-phonenumber')
const { imageToWebp, videoToWebp, writeExifImg, writeExifVid } = require('./lib/exif')
const { smsg, isUrl, generateMessageTag, getBuffer, getSizeMedia, fetchJson, await, sleep, runtime } = require('./lib/myfunc')
const settings = JSON.parse(fs.readFileSync('./Dii.json'))


var low
try {
low = require('lowdb')
} catch (e) {
low = require('./lib/lowdb')
}

const color = (text, color) => {
return !color ? chalk.green(text) : chalk.keyword(color)(text)
}

const { Low, JSONFile } = low
const mongoDB = require('./lib/mongoDB')

const pairingCode = !!settings.pairingNumber || process.argv.includes("--pairing-code")
const useMobile = process.argv.includes("--mobile")

const question = (text) => {
const rl = readline.createInterface({
input: process.stdin,
output: process.stdout})
return new Promise((resolve) => {
rl.question(text, resolve)})
}

const msgRetryCounterCache = new NodeCache()

const store = makeInMemoryStore({ logger: pino().child({ level: 'silent', stream: 'store' }) })

async function DiiOffcStart() {
const { state, saveCreds } = await useMultiFileAuthState('./session')
   process.on("unhandledRejection", (err) => console.error(err))
   
global.opts = new Object(yargs(process.argv.slice(2)).exitProcess(false).parse())
global.db = new Low(
  /https?:\/\//.test(opts['db'] || '') ?
    new cloudDBAdapter(opts['db']) : /mongodb/.test(opts['db']) ?
      new mongoDB(opts['db']) :
      new JSONFile(`data/database.json`)
)
global.DATABASE = global.db
global.loadDatabase = async function loadDatabase() {
  if (global.db.READ) return new Promise((resolve) => setInterval(function () { (!global.db.READ ? (clearInterval(this), resolve(global.db.data == null ? global.loadDatabase() : global.db.data)) : null) }, 1 * 1000))
  if (global.db.data !== null) return
  global.db.READ = true
  await global.db.read()
  global.db.READ = false
  global.db.data = {
    users: {}, 
    chats: {}, 
    bot: {}, 
    settings: {},
    ...(global.db.data || {})
  }
  global.db.chain = _.chain(global.db.data)
}
loadDatabase()

if (global.db) setInterval(async () => {
    if (global.db.data) await global.db.write()
  }, 30 * 1000)
  
setInterval(async () => {
const directoryPath = './session'
fs.readdir(directoryPath, (err, files) => {
if (err) {
console.log('Error reading directory:', err)
return
}
files.forEach((file) => {
const filePath = path.join(directoryPath, file)
const fileStat = fs.statSync(filePath);
const currentTime = new Date().getTime()
const fileModifiedTime = fileStat.mtime.getTime()
const timeDifference = currentTime - fileModifiedTime
const oneHourInMilliseconds = 1800000
if (timeDifference >= oneHourInMilliseconds && file !== 'creds.json') {
fs.unlink(filePath, (err) => {
if (err) {
return console.log('Error deleting file:', err)
}
console.log('Sampah Session Berhasil Dibersihkan.')
})}
})
})
}, 5000)
  
const DiiOffc = makeWASocket({
logger: pino({ level: "fatal" }).child({ stream: "store" }), 
printQRInTerminal: !pairingCode,
mobile: useMobile,
auth: {
creds: state.creds,
keys: makeCacheableSignalKeyStore(state.keys, pino({ level: "fatal" }).child({ stream: "store" })),
},
browser: ['Ubuntu', 'Chrome', ''], 
generateHighQualityLinkPreview: true,
markOnlineOnConnect: true, 
getMessage: async (key) => {
let jid = jidNormalizedUser(key.remoteJid)
let msg = await store.loadMessage(jid, key.id)
return msg?.message || ""
},
msgRetryCounterCache,
connectTimeoutMs: undefined
})
   

if (pairingCode && !DiiOffc.authState.creds.registered) {
if (useMobile) throw new Error('Cannot use pairing code with mobile api')

let phoneNumber
if (!!settings.pairingNumber) {
phoneNumber = settings.pairingNumber.replace(/[^0-9]/g, '')

if (!Object.keys(PHONENUMBER_MCC).some(v => phoneNumber.startsWith(v))) {
console.log(chalk.bgBlack(chalk.redBright("Start with your country's WhatsApp code, Example : 62xxx")))
process.exit(0)
}
} else {
phoneNumber = await question(chalk.bgBlack(chalk.greenBright(`Please type your WhatsApp number : `)))
phoneNumber = phoneNumber.replace(/[^0-9]/g, '')

if (!Object.keys(PHONENUMBER_MCC).some(v => phoneNumber.startsWith(v))) {
console.log(chalk.bgBlack(chalk.redBright("Mulailah Dengan Kode WhatsApp Negara Anda, Contoh : 62xxx")))

phoneNumber = await question(chalk.bgBlack(chalk.greenBright(`Silakan ketik nomor WhatsApp Anda : `)))
phoneNumber = phoneNumber.replace(/[^0-9]/g, '')
rl.close()
}}

setTimeout(async () => {
let code = await DiiOffc.requestPairingCode(phoneNumber)
code = code?.match(/.{1,4}/g)?.join("-") || code
console.log(chalk.black(chalk.bgGreen(`Kode Pairing Kamu : `)), chalk.black(chalk.white(code)))
}, 3000)
}

   
if (useMobile && !DiiOffc.authState.creds.registered) {
const { registration } = DiiOffc.authState.creds || { registration: {} }

if (!registration.phoneNumber) {
let phoneNumber = await question(chalk.bgBlack(chalk.greenBright(`Silakan ketik nomor WhatsApp Anda : `)))
phoneNumber = phoneNumber.replace(/[^0-9]/g, '')

if (!Object.keys(PHONENUMBER_MCC).some(v => phoneNumber.startsWith(v))) {
console.log(chalk.bgBlack(chalk.redBright("Mulailah dengan kode WhatsApp negara Anda, Contoh : 62xxx")))

phoneNumber = await question(chalk.bgBlack(chalk.greenBright(`Silakan ketik nomor WhatsApp Anda : `)))
phoneNumber = phoneNumber.replace(/[^0-9]/g, '')
}
registration.phoneNumber = "+" + phoneNumber
}

const phoneNumber = parsePhoneNumber(registration.phoneNumber)
if (!phoneNumber.isValid()) throw new Error('Nomor telepon tidak valid : ' + registration.phoneNumber)
registration.phoneNumber = phoneNumber.format("E.164")
registration.phoneNumberCountryCode = phoneNumber.countryCallingCode
registration.phoneNumberNationalNumber = phoneNumber.nationalNumber

const mcc = PHONENUMBER_MCC[phoneNumber.countryCallingCode]
registration.phoneNumberMobileCountryCode = mcc

async function enterCode() {
try {
const code = await question(chalk.bgBlack(chalk.greenBright(`Silakan Masukkan Kode OTP Anda : `)))
const response = await DiiOffc.register(code.replace(/[^0-9]/g, '').trim().toLowerCase())
console.log(chalk.bgBlack(chalk.greenBright("Berhasil mendaftarkan nomor telepon Anda.")))
console.log(response)
rl.close()
} catch (e) {
console.error('Gagal mendaftarkan nomor telepon Anda. Silakan coba lagi.\n', e)
await askOTP()
}}

async function enterCaptcha() {
const response = await sock.requestRegistrationCode({ ...registration, method: 'captcha' })
const pathFile = path.join(process.cwd(), "temp", "captcha.png")
fs.writeFileSync(pathFile, Buffer.from(response.image_blob, 'base64'))
await require(pathFile)
const code = await question(chalk.bgBlack(chalk.greenBright(`Please Enter Your Captcha Code : `)))
fs.unlinkSync(pathFile)
registration.captcha = code.replace(/["']/g, '').trim().toLowerCase()
}

async function askOTP() {
if (!registration.method) {
let code = await question(chalk.bgBlack(chalk.greenBright('Metode apa yang ingin Anda gunakan? "sms" atau "voice" : ')))
code = code.replace(/["']/g, '').trim().toLowerCase()

if (code !== 'sms' && code !== 'voice') return await askOTP()
registration.method = code
}
try {
await DiiOffc.requestRegistrationCode(registration)
await enterCode()
} catch (e) {
console.error('Gagal mendaftarkan nomor telepon Anda. Silakan coba lagi.\n', e)
if (e?.reason === 'code_checkpoint') {
await enterCaptcha()
}
await askOTP()
}
}
await askOTP()
}
    
DiiOffc.ev.on('call', async (fatihh) => {
let botNumber = await DiiOffc.decodeJid(DiiOffc.user.id)
let ciko = antiCall
if (!ciko) return
console.log(fatihh)
for (let tihh of fatihh) {
if (tihh.isGroup == false) {
if (tihh.status == "offer") {
let pa7rick = await DiiOffc.sendTextWithMentions(tihh.from, `Bot tidak bisa menerima panggilan ${tihh.isVideo ? `video` : `suara`}!!. Maaf @${tihh.from.split('@')[0]} kamu akan diblokir. Jika tidak sengaja silahkan hubungi Owner untuk membuka blokiran`)
DiiOffc.sendContact(tihh.from, [settings.owner.split("@")[0]], pa7rick)
await sleep(8000)
await DiiOffc.updateBlockStatus(tihh.from, "block")
}}}
})

DiiOffc.ev.on('messages.upsert', async chatUpdate => {
try {
mek = chatUpdate.messages[0]
if (!mek.message) return
mek.message = (Object.keys(mek.message)[0] === 'ephemeralMessage') ? mek.message.ephemeralMessage.message : mek.message
if (mek.key && mek.key.remoteJid === 'status@broadcast') return
if (settings.autoRead) DiiOffc.readMessages([mek.key])
if (!DiiOffc.public && !mek.key.fromMe && chatUpdate.type === 'notify') return
if (mek.key.id.startsWith('Dii Offc')) return
m = smsg(DiiOffc, mek, store)
require("./DiiOffc")(DiiOffc, m, chatUpdate, store)
} catch (err) {
console.log(err)
}
})

DiiOffc.ev.on('group-participants.update', async (anu) => {
console.log(anu)
try {
let metadata = await DiiOffc.groupMetadata(anu.id)
let participants = anu.participants
for (let num of participants) {
try {
ppuser = await DiiOffc.profilePictureUrl(num, 'image')
} catch {
ppuser = 'https://telegra.ph/file/a059a6a734ed202c879d3.jpg'
}
if (settings.welcome) {
if (anu.action == 'add') {
DiiOffc.sendMessage(anu.id, {text: `Selamat Datang Kak @${num.split("@")[0]}`, 
contextInfo: {mentionedJid: [num], externalAdReply: { thumbnailUrl: ppuser, title: '© Welcome Message', body: '', renderLargerThumbnail: true, sourceUrl: settings.linkgc, mediaType: 1}}})
} 
if (anu.action == 'remove') { 
DiiOffc.sendMessage(anu.id, {text: `Selamat Tinggal Kak @${num.split("@")[0]}`, 
contextInfo: {mentionedJid: [num], externalAdReply: { thumbnailUrl: ppuser, title: '© Leaving Message', body: '', renderLargerThumbnail: true, sourceUrl: settings.linkgc, mediaType: 1}}})
}
} 
if (anu.action == 'promote') {
DiiOffc.sendMessage(anu.id, {text: `@${num.split('@')[0]} Sekarang kamu jadi Admin`, 
contextInfo: {mentionedJid: [num], externalAdReply: { thumbnailUrl: ppuser, title: '© Promote Message', body: '', renderLargerThumbnail: true, sourceUrl: settings.linkgc, mediaType: 1}}})    
} 
if (anu.action == 'demote') {
DiiOffc.sendMessage(anu.id, {text: `@${num.split('@')[0]} Sekarang kamu bukan Admin`, 
contextInfo: {mentionedJid: [num], externalAdReply: { thumbnailUrl: ppuser, title: '© Demote Message', body: '', renderLargerThumbnail: true, sourceUrl: settings.linkgc, mediaType: 1}}})  
}
}
} catch (err) {
console.log(err)
}
})
	
DiiOffc.decodeJid = (jid) => {
if (!jid) return jid
if (/:\d+@/gi.test(jid)) {
let decode = jidDecode(jid) || {}
return decode.user && decode.server && decode.user + '@' + decode.server || jid
} else return jid
}
    
DiiOffc.ev.on('contacts.update', update => {
for (let contact of update) {
let id = DiiOffc.decodeJid(contact.id)
if (store && store.contacts) store.contacts[id] = { id, name: contact.notify }
}
})

DiiOffc.getName = (jid, withoutContact  = false) => {
id = DiiOffc.decodeJid(jid)
withoutContact = DiiOffc.withoutContact || withoutContact 
let v
if (id.endsWith("@g.us")) return new Promise(async (resolve) => {
v = store.contacts[id] || {}
if (!(v.name || v.subject)) v = DiiOffc.groupMetadata(id) || {}
resolve(v.name || v.subject || PhoneNumber('+' + id.replace('@s.whatsapp.net', '')).getNumber('international'))
})
else v = id === '0@s.whatsapp.net' ? {
id,
name: 'WhatsApp'
} : id === DiiOffc.decodeJid(DiiOffc.user.id) ?
DiiOffc.user :
(store.contacts[id] || {})
return (withoutContact ? '' : v.name) || v.subject || v.verifiedName || PhoneNumber('+' + jid.replace('@s.whatsapp.net', '')).getNumber('international')
}
    
DiiOffc.sendContact = async (jid, kon, quoted = '', opts = {}) => {
let list = []
for (let i of kon) {
list.push({
displayName: settings.namaowner,
vcard: `BEGIN:VCARD\nVERSION:3.0\nN:${settings.namaowner}\nFN:${settings.namaowner}\nitem1.TEL;waid=${i}:${i}\nitem1.X-ABLabel:Ponsel\nitem2.EMAIL;type=INTERNET:killua2410@gmail.com\nitem2.X-ABLabel:Email\nitem3.URL:${settings.website}\nitem3.X-ABLabel:Website\nitem4.ADR:;;Indonesia;;;;\nitem4.X-ABLabel:Region\nEND:VCARD`
})
}
DiiOffc.sendMessage(jid, { contacts: { displayName: `${list.length} Kontak`, contacts: list }, ...opts }, { quoted })
}
    
DiiOffc.public = true

DiiOffc.serializeM = (m) => smsg(DiiOffc, m, store)

DiiOffc.ev.on('connection.update', async (update) => {
const { connection, lastDisconnect } = update	    
if (connection === 'close') {
let reason = new Boom(lastDisconnect?.error)?.output.statusCode
if (reason === DisconnectReason.badSession) { console.log(`Bad Session File, Please Delete Session and Scan Again`); 
DiiOffcStart(); 
} else if (reason === DisconnectReason.connectionClosed) { console.log("Connection closed, reconnecting...."); DiiOffcStart(); 
} else if (reason === DisconnectReason.connectionLost) { console.log("Connection Lost from Server, reconnecting..."); DiiOffcStart(); 
} else if (reason === DisconnectReason.connectionReplaced) { console.log("Connection Replaced, Another New Session Opened, Please Close Current Session First"); DiiOffcStart(); 
} else if (reason === DisconnectReason.loggedOut) { console.log(`Device Logged Out, Please Scan Again And Run.`); DiiOffc.logout(); 
} else if (reason === DisconnectReason.restartRequired) { console.log("Restart Required, Restarting..."); DiiOffcStart(); 
} else if (reason === DisconnectReason.timedOut) { console.log("Connection TimedOut, Reconnecting..."); DiiOffcStart(); 
} else if (reason === DisconnectReason.Multidevicemismatch) { console.log("Multi device mismatch, please scan again"); DiiOffc.logout(); 
} else DiiOffc.end(`Unknown DisconnectReason: ${reason}|${connection}`)
}
if (connection === 'open') {
await DiiOffc.sendMessage('6285348168927@s.whatsapp.net', {text: `
*[ ⚠️ N O T I F I K A S I ]*
Bot Berhasil Tersambung.
`})}
})

DiiOffc.ev.on('creds.update', saveCreds)


DiiOffc.sendFileUrl = async (jid, url, caption, quoted, options = {}) => {
let mime = '';
let res = await axios.head(url)
mime = res.headers['content-type']
if (mime.split("/")[1] === "gif") {
return DiiOffc.sendMessage(jid, { video: await getBuffer(url), caption: caption, gifPlayback: true, ...options}, { quoted: quoted, ...options})
}
let type = mime.split("/")[0]+"Message"
if (mime === "application/pdf"){
return DiiOffc.sendMessage(jid, { document: await getBuffer(url), mimetype: 'application/pdf', caption: caption, ...options}, { quoted: quoted, ...options })
}
if (mime.split("/")[0] === "image"){
return DiiOffc.sendMessage(jid, { image: await getBuffer(url), caption: caption, ...options}, { quoted: quoted, ...options})
}
if (mime.split("/")[0] === "video"){
return DiiOffc.sendMessage(jid, { video: await getBuffer(url), caption: caption, mimetype: 'video/mp4', ...options}, { quoted: quoted, ...options })
}
if (mime.split("/")[0] === "audio"){
return DiiOffc.sendMessage(jid, { audio: await getBuffer(url), caption: caption, mimetype: 'audio/mpeg', ...options}, { quoted: quoted, ...options })
}}
    
DiiOffc.sendText = (jid, text, quoted = '', options) => DiiOffc.sendMessage(jid, { text: text, ...options }, { quoted, ...options })

DiiOffc.sendImage = async (jid, path, caption = '', quoted = '', options) => {
let buffer = Buffer.isBuffer(path) ? path : /^data:.*?\/.*?;base64,/i.test(path) ? Buffer.from(path.split`,`[1], 'base64') : /^https?:\/\//.test(path) ? await (await getBuffer(path)) : fs.existsSync(path) ? fs.readFileSync(path) : Buffer.alloc(0)
return await DiiOffc.sendMessage(jid, { image: buffer, caption: caption, ...options }, { quoted })
}


DiiOffc.sendVideo = async (jid, path, caption = '', quoted = '', gif = false, options) => {
let buffer = Buffer.isBuffer(path) ? path : /^data:.*?\/.*?;base64,/i.test(path) ? Buffer.from(path.split`,`[1], 'base64') : /^https?:\/\//.test(path) ? await (await getBuffer(path)) : fs.existsSync(path) ? fs.readFileSync(path) : Buffer.alloc(0)
return await DiiOffc.sendMessage(jid, { video: buffer, caption: caption, gifPlayback: gif, ...options }, { quoted })
}


DiiOffc.sendAudio = async (jid, path, quoted = '', ptt = false, options) => {
let buffer = Buffer.isBuffer(path) ? path : /^data:.*?\/.*?;base64,/i.test(path) ? Buffer.from(path.split`,`[1], 'base64') : /^https?:\/\//.test(path) ? await (await getBuffer(path)) : fs.existsSync(path) ? fs.readFileSync(path) : Buffer.alloc(0)
return await DiiOffc.sendMessage(jid, { audio: buffer, ptt: ptt, ...options }, { quoted })
}

DiiOffc.sendTextWithMentions = async (jid, text, quoted, options = {}) => DiiOffc.sendMessage(jid, { text: text, mentions: [...text.matchAll(/@(\d{0,16})/g)].map(v => v[1] + '@s.whatsapp.net'), ...options }, { quoted })


DiiOffc.sendImageAsSticker = async (jid, path, quoted, options = {}) => {
let buff = Buffer.isBuffer(path) ? path : /^data:.*?\/.*?;base64,/i.test(path) ? Buffer.from(path.split`,`[1], 'base64') : /^https?:\/\//.test(path) ? await (await getBuffer(path)) : fs.existsSync(path) ? fs.readFileSync(path) : Buffer.alloc(0)
let buffer
if (options && (options.packname || options.author)) {
buffer = await writeExifImg(buff, options)
} else {
buffer = await imageToWebp(buff)
}
await DiiOffc.sendMessage(jid, { sticker: { url: buffer }, ...options }, { quoted })
return buffer
}


DiiOffc.sendVideoAsSticker = async (jid, path, quoted, options = {}) => {
let buff = Buffer.isBuffer(path) ? path : /^data:.*?\/.*?;base64,/i.test(path) ? Buffer.from(path.split`,`[1], 'base64') : /^https?:\/\//.test(path) ? await (await getBuffer(path)) : fs.existsSync(path) ? fs.readFileSync(path) : Buffer.alloc(0)
let buffer
if (options && (options.packname || options.author)) {
buffer = await writeExifVid(buff, options)
} else {
buffer = await videoToWebp(buff)
}
await DiiOffc.sendMessage(jid, { sticker: { url: buffer }, ...options }, { quoted })
return buffer
}
	

DiiOffc.downloadAndSaveMediaMessage = async (message, filename, attachExtension = true) => {
let quoted = message.msg ? message.msg : message
let mime = (message.msg || message).mimetype || ''
let messageType = message.mtype ? message.mtype.replace(/Message/gi, '') : mime.split('/')[0]
const stream = await downloadContentFromMessage(quoted, messageType)
let buffer = Buffer.from([])
for await(const chunk of stream) {
buffer = Buffer.concat([buffer, chunk])
}
let type = await FileType.fromBuffer(buffer)
trueFileName = attachExtension ? ('./sampah/' + makeid + '.' + type.ext) : filename
await fs.writeFileSync(trueFileName, buffer)
return trueFileName
}

DiiOffc.downloadMediaMessage = async (message) => {
let mime = (message.msg || message).mimetype || ''
let messageType = message.mtype ? message.mtype.replace(/Message/gi, '') : mime.split('/')[0]
const stream = await downloadContentFromMessage(message, messageType)
let buffer = Buffer.from([])
for await(const chunk of stream) {
buffer = Buffer.concat([buffer, chunk])
}
return buffer
} 
  
DiiOffc.sendMedia = async (jid, path, quoted, options = {}) => {
let { ext, mime, data } = await DiiOffc.getFile(path)
let messageType = mime.split('/')[0]
let type = messageType.replace('application', 'document') || messageType
return await DiiOffc.sendMessage(jid, {[`${type}`]: data, mimetype: mime, ...options}, {quoted: quoted})
}

DiiOffc.copyNForward = async (jid, message, forceForward = false, options = {}) => {
let vtype
if (options.readViewOnce) {
message.message = message.message && message.message.ephemeralMessage && message.message.ephemeralMessage.message ? message.message.ephemeralMessage.message : (message.message || undefined)
vtype = Object.keys(message.message.viewOnceMessage.message)[0]
delete(message.message && message.message.ignore ? message.message.ignore : (message.message || undefined))
delete message.message.viewOnceMessage.message[vtype].viewOnce
message.message = {
...message.message.viewOnceMessage.message
}
}

let mtype = Object.keys(message.message)[0]
let content = await generateForwardMessageContent(message, forceForward)
let ctype = Object.keys(content)[0]
let context = {}
if (mtype != "conversation") context = message.message[mtype].contextInfo
        content[ctype].contextInfo = {
            ...context,
            ...content[ctype].contextInfo
        }
const waMessage = await generateWAMessageFromContent(jid, content, options ? {
            ...content[ctype],
            ...options,
            ...(options.contextInfo ? {
                contextInfo: {
                    ...content[ctype].contextInfo,
                    ...options.contextInfo
                }
            } : {})
        } : {})
await DiiOffc.relayMessage(jid, waMessage.message, { messageId:  waMessage.key.id })
return waMessage
}
return DiiOffc
}

DiiOffcStart()

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})